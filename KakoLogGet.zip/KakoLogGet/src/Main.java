import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.zip.GZIPInputStream;

import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;

public class Main {

	public static void main(String[] args)  throws Exception {
		
		
		//-----------------------------------------------------------
		// gzip解凍
		readFolder("");
		//-----------------------------------------------------------
		
		//-----------------------------------------------------------
		// tar解凍
		String output_path = "//Users/yasuhiro/Desktop/work_nksol";
		decompressTar(output_path);
		//-----------------------------------------------------------
		
		// gzip解凍
		readFolder("");
		
		// カレントディレクトリ作成
		String current_path = "//Users/yasuhiro/Desktop/work_nksol";
		mkdir(current_path);
		
		//ファイル移動
		String input_dir_path = "//Users/yasuhiro/Desktop/work_nksol/";
		moveFile(input_dir_path);
		
		
		
	}
	
	public static void readFolder(String input_dir_path) throws IOException {
		File file = new File(input_dir_path);
		File[] files = file.listFiles();
		System.out.println(file.getPath() + file.isFile());
		if (files == null)  {
			return;
		}
		for ( File target_file : files) {
			System.out.println(target_file.getName());
			if (!target_file.exists()) { 
				continue;
			} else if (target_file.isDirectory()) {
				continue;
			} else {
				//ディレクトリ名要変更
				decompressGzip(target_file,"//Users/yasuhiro/Desktop/work_nksol/" + target_file.getName().replace(".gz", ".tar"));
			}
		}
	}
	
	public static void decompressGzip(File input_file, String output_file) throws IOException {
		/** Fixme  */
		File output = new File(output_file);
		try (GZIPInputStream in = new GZIPInputStream(new FileInputStream(input_file))){
			try (FileOutputStream out = new FileOutputStream(output)){
				byte[] buffer = new byte[1024];
	        	int len;
	        	while((len = in.read(buffer)) != -1){
	       			out.write(buffer, 0, len);
	          	}
	       		out.close();
	       		input_file.delete();
	       		
         	} catch (IOException e) {
         		e.printStackTrace();
	        }
	     } catch (Exception e) {
	   		e.printStackTrace();
	   	}
	}
	
	public static void decompressTar(String output_path)  throws IOException {
		File input_file_path = new File("//Users/yasuhiro/Desktop/work_nksol/");
		File[] files = input_file_path.listFiles();
		if (files == null) {
			return;
		}
		for (File target_file : files) {
			if (!target_file.exists()) {
				continue;
			}else if (target_file.isDirectory()) {
				continue;
			}
			 System.out.println(target_file.getName());

		try( FileInputStream  fis  = new FileInputStream( target_file );
	         TarArchiveInputStream tais = new TarArchiveInputStream( fis ) ) {
	         // エントリーを1つずつファイル・フォルダに復元
	         ArchiveEntry entry   = null;
	         while( ( entry = tais.getNextEntry() ) != null ) {
	        	 // ファイルを作成
	        	 File file = new File( output_path + "/" + entry.getName() );
	        	 // フォルダ・エントリの場合はフォルダを作成して次へ
	        	 if( entry.isDirectory() ){
	        		 continue;
	        	 }
	 
	        	 // ファイル出力する場合
	        	 // フォルダが存在しない場合は事前にフォルダ作成
	        	 if( !file.getParentFile().exists() ){
	        		 file.getParentFile().mkdirs(); 
	        	 }
		         // ファイル出力
		         try(FileOutputStream fos = new FileOutputStream( file ) ;
		        	BufferedOutputStream bos = new BufferedOutputStream( fos ) ){
		        	 // エントリの出力
		        	 	int size = 0;
		        	 	byte[] buf = new byte[ 1024 ];
		        	 	while( tais.read( buf ) > 0 ) {
		        	 		bos.write( buf , 0 , size );
		        	 	}
		         	}
		         }
			}
		}
	}
	/**
	 * ログの種類ごとのディレクトリ作成
	 * 
	 * @param file_path
	 */
	public static void mkdir(String file_path) {
		File client_output_log_dir = new File(file_path + "/01.クライアント");
		File logger_output_dir = new File(file_path + "/02.logger_output");
		File logger_err_dir = new File(file_path + "/03.logger_err");
		File access_log = new File(file_path + "/05.access_log");
		File access_err_log = new File(file_path + "/06.access_err_log");
		File logger_err_ex_log = new File(file_path + "/07.logger_err_ex_log");
		File logger_ope_err_log = new File(file_path + "/08.logger_ope_err_log");
	
		client_output_log_dir.mkdir();
		logger_output_dir.mkdir();
		logger_err_dir.mkdir();
		access_log.mkdir();
		access_err_log.mkdir();
		logger_err_ex_log.mkdir();
		logger_ope_err_log.mkdir();
	}
	
	private static void moveFile(String dir_path) throws IOException {
		// TODO Auto-generated method stub
		try {
			File file = new File(dir_path);
			File[] files = file.listFiles();
			if (files == null) {
				return;
			}
			for (File target_file : files) {
				System.out.println(target_file.getName());
				if (!target_file.exists()) {
					continue;
				}else if (target_file.isDirectory()) {
					continue;
				}
				Path from = null;
				Path to = null;
				// logger_client_log　move
				if (target_file.getName().contains("logger_client_output.log")) {
			        from = Paths.get(target_file.getPath());
			        to = Paths.get("//Users/yasuhiro/Desktop/work_nksol/01.クライアント/" + target_file.getName());
			        Files.move(from, to);
			    // logger_output.log move
				} else if (target_file.getName().contains("logger_output.log")) {
					from = Paths.get(target_file.getPath());
					to = Paths.get("//Users/yasuhiro/Desktop/work_nksol/02.logger_output/" + target_file.getName());
					Files.move(from, to);
				// logger_err.log move
				} else if (target_file.getName().contains("logger_err.log")) {
					from = Paths.get(target_file.getPath());
					to = Paths.get("//Users/yasuhiro/Desktop/work_nksol/03.logger_err/" + target_file.getName());
					Files.move(from, to);
				// access_log move
				} else if (target_file.getName().contains("access_log")) {
					from = Paths.get(target_file.getPath());
					to = Paths.get("//Users/yasuhiro/Desktop/work_nksol/05.access_log/" + target_file.getName());
					Files.move(from, to);
				// error_log move
				} else if (target_file.getName().contains("error_log")) {
					from = Paths.get(target_file.getPath());
					to = Paths.get("//Users/yasuhiro/Desktop/work_nksol/06.access_err_log/" + target_file.getName());
					Files.move(from, to);
				} else if (target_file.getName().contains("logger_err_ex.log")) {
					System.out.println("logger_err_ex.log" + "の処理");
					from = Paths.get(target_file.getPath());
					to = Paths.get("//Users/yasuhiro/Desktop/work_nksol/07.logger_err_ex_log/" + target_file.getName());
					Files.move(from, to);
				} else if (target_file.getName().contains("logger_ope_err.log")) {
					from = Paths.get(target_file.getPath());
					to = Paths.get("//Users/yasuhiro/Desktop/work_nksol/08.logger_ope_err_log/" + target_file.getName());
					Files.move(from, to);
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
}
